package com.marwadi.explicitintentexample;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class design1 extends AppCompatActivity {
  TextView t_mame,t_contact;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_design1);

        t_mame = findViewById(R.id.t_name);
        t_contact = findViewById(R.id.t_contact);

        Intent intent= getIntent();

       t_mame.setText(intent.getStringExtra("name"));
        t_contact.setText(intent.getStringExtra("contact"));
}
    }