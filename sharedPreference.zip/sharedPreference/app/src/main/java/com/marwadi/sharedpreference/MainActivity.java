package com.marwadi.sharedpreference;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {


    Button b_login,b_reg;

    EditText e_user, e_pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);


        b_login=findViewById(R.id.b_login);

        b_reg=findViewById(R.id.b_register);

        e_pass=findViewById(R.id.e_pass);

        e_user=findViewById(R.id.e_user);

        b_reg.setOnClickListener(v -> {

            SharedPreferences sp=getSharedPreferences("Data", MODE_PRIVATE);

            SharedPreferences.Editor editor=sp.edit();

            editor.putString("user",e_user.getText().toString());
            editor.putString("pass",e_pass.getText().toString());

            editor.apply();

            Toast.makeText(this, "user created successfully", Toast.LENGTH_SHORT).show();


        });

        b_login.setOnClickListener(v -> {

            SharedPreferences sp=getSharedPreferences("Data", MODE_PRIVATE);

            if(sp.contains("user"))
            {

              String user= sp.getString("user","");
              String pass=sp.getString("pass","");
              if (user.equals(e_user.getText().toString()) && pass.equals(e_pass.getText().toString()))
              {

                  Toast.makeText(this, "Welcome", Toast.LENGTH_SHORT).show();
              }
              else
              {

                  Toast.makeText(this, "sorry this not found ", Toast.LENGTH_SHORT).show();
              }

            }

            else {
                Toast.makeText(this, "no records found", Toast.LENGTH_SHORT).show();

            }




        });


    }
}